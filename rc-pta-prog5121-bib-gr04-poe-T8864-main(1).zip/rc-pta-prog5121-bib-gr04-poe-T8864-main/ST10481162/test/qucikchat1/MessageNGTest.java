/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package qucikchat1;

import static org.testng.Assert.*;
import org.testng.annotations.Test;
import java.util.regex.Pattern;

/**
 *
 * @author loren
 */
public class MessageNGTest {
    
    public MessageNGTest() {
    }

    @Test
    public void testIsValidMessageRecipient() {
         Message validMessage = new Message("+12345678901", "Test content");
        assertTrue(validMessage.isValidMessageRecipient());
        
        Message invalidMessage1 = new Message("12345678901", "Test content");
        assertFalse(invalidMessage1.isValidMessageRecipient());
        
        Message invalidMessage2 = new Message("+123", "Test content");
        assertFalse(invalidMessage2.isValidMessageRecipient());
        
        Message invalidMessage3 = new Message("+abcdefghijk", "Test content");
        assertFalse(invalidMessage3.isValidMessageRecipient());
    }

    @Test
    public void testIsValidMessageLength() {
        
        Message shortMessage = new Message("+12345678901", "Short");
        assertTrue(shortMessage.isValidMessageLength());
        
        StringBuilder longContent = new StringBuilder();
        for (int i = 0; i < 250; i++) {
            longContent.append("a");
        }
        Message exactLengthMessage = new Message("+12345678901", longContent.toString());
        assertTrue(exactLengthMessage.isValidMessageLength());
        
        Message tooLongMessage = new Message("+12345678901", longContent.toString() + "a");
        assertFalse(tooLongMessage.isValidMessageLength());
    }

    @Test
    public void testCreateMessageHash() {
        
         Message message = new Message("+12345678901", "This is a test message");
        String hash = message.getMessageHash();
        
        // Verify format: first 2 chars of messageId + : + messageNumber + : + firstWord + lastWord
        assertTrue(hash.matches("^\\d{2}:\\d+:THISMESSAGE$"));
        
        Message emptyMessage = new Message("+12345678901", "");
        String emptyHash = emptyMessage.getMessageHash();
        assertTrue(emptyHash.matches("^\\d{2}:\\d+:N/AN/A$"));
        
        Message singleWordMessage = new Message("+12345678901", "Single");
        String singleHash = singleWordMessage.getMessageHash();
        assertTrue(singleHash.matches("^\\d{2}:\\d+:SINGLEN/A$"));
        
    }

    @Test
    public void testGetMessageId() {
         Message message = new Message("+12345678901", "Test");
        String messageId = message.getMessageId();
        
        // Verify ID is 10 digits
        assertTrue(messageId.matches("^\\d{10}$"));
        
        // Verify IDs are unique
        Message anotherMessage = new Message("+12345678901", "Test");
        assertNotEquals(message.getMessageId(), anotherMessage.getMessageId());
        
    }

    @Test
    public void testGetMessageNumber() {
        // Reset the static counter for this test
        // Note: This might not work correctly due to static counter being shared across tests
        // In a real scenario, you'd want to use reflection to reset the counter or redesign the class
        
        Message firstMessage = new Message("+12345678901", "First");
        assertEquals(firstMessage.getMessageNumber(), 1);
        
        Message secondMessage = new Message("+12345678901", "Second");
        assertEquals(secondMessage.getMessageNumber(), 2);
    }

    @Test
    public void testGetRecipient() {
         String recipient = "+12345678901";
        Message message = new Message(recipient, "Test");
        assertEquals(message.getRecipient(), recipient);
     
    }

    @Test
    public void testGetContent() {
          String content = "Test content";
        Message message = new Message("+12345678901", content);
        assertEquals(message.getContent(), content);
    }

    @Test
    public void testGetMessageHash() {
         String content = "Test content for hash";
        Message message = new Message("+12345678901", content);
        String hash = message.getMessageHash();
        
        // Verify the hash contains parts from messageId, messageNumber, and content
        assertTrue(hash.startsWith(message.getMessageId().substring(0, 2)));
        assertTrue(hash.contains(":" + message.getMessageNumber() + ":"));
        assertTrue(hash.contains("TEST"));
        assertTrue(hash.contains("HASH"));
    }
    
}
